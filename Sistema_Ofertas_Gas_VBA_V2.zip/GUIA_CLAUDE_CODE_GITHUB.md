# 🚀 GUÍA RÁPIDA: Claude Code + GitHub para desarrollo VBA

## 📋 PREREQUISITOS

1. ✅ Tienes Claude Code configurado via web
2. ✅ Tienes GitHub configurado en tu máquina
3. ✅ Tienes tu repo: https://github.com/gautxori-yuyu/ofergas

---

## 🎯 PARTE 1: SUBIR ESTOS ARCHIVOS A GITHUB

### Paso 1: Descargar el ZIP que te doy
- Descarga `Sistema_Ofertas_FASE1.zip`
- Extrae los archivos en una carpeta local

### Paso 2: Clonar tu repo (si no lo tienes ya)
```bash
cd ~/Documents  # O donde quieras trabajar
git clone https://github.com/gautxori-yuyu/ofergas.git
cd ofergas
```

### Paso 3: Crear rama para FASE 1
```bash
git checkout -b fase1-catalogos-32
```

### Paso 4: Copiar archivos al repo
```bash
# Crear estructura de carpetas
mkdir -p VBA_modules
mkdir -p VBA_classes

# Copiar archivos
cp ~/Downloads/modOfertaTypes.bas VBA_modules/
cp ~/Downloads/modMACROLeerOfertas.bas VBA_modules/
cp ~/Downloads/clsCatalogos.cls VBA_classes/
cp ~/Downloads/clsOfertaRepository.cls VBA_classes/
cp ~/Downloads/README_FASE1.txt .
```

### Paso 5: Commit y push
```bash
git add .
git commit -m "FASE 1: Implementar 32 catálogos nuevos (grupos A,B,E,H,J,C,D)"
git push origin fase1-catalogos-32
```

### Paso 6: Crear Pull Request en GitHub
- Ve a https://github.com/gautxori-yuyu/ofergas
- Verás un botón "Compare & pull request"
- Crea el PR y haz merge a main

---

## 🎯 PARTE 2: TRABAJAR CON CLAUDE CODE

### ¿Qué es Claude Code?
- Es Claude corriendo en tu terminal
- Tiene acceso directo a tus archivos locales
- Puede ejecutar comandos, editar código, hacer commits

### Paso 1: Abrir proyecto en Claude Code
```bash
cd ~/Documents/ofergas
claude-code
```

O desde la web: https://code.claude.ai

### Paso 2: Decirle a Claude qué hacer
Ejemplos de prompts efectivos:

**📝 Para editar código:**
```
"En clsCatalogos.cls, añade el método CargarDepositosEntrada 
siguiendo el patrón de los métodos existentes"
```

**🔍 Para analizar:**
```
"Lee todos los archivos .cls y .bas y dime qué funciones
están incompletas o faltan implementar"
```

**🐛 Para debugging:**
```
"El método CargarExtras está dando error en la línea 245.
Revisa el código y sugiere la corrección"
```

**📦 Para Git:**
```
"Haz commit de los cambios con el mensaje:
'Implementar FASE 2: Grupos F, G, I'"
```

### Paso 3: Workflow recomendado

#### Ciclo de desarrollo VBA con Claude Code:

1. **Planificar** (en claude.ai o Claude Code)
   ```
   "Necesito implementar los catálogos de la FASE 2.
   ¿Qué archivos debo modificar y en qué orden?"
   ```

2. **Implementar** (Claude Code)
   ```
   "Modifica clsCatalogos.cls para añadir:
   - DepositosEntrada
   - DepositosFinal
   - TiposMaterial"
   ```

3. **Probar** (Claude Code puede ayudar)
   ```
   "Crea una macro de prueba que verifique que
   los 3 nuevos catálogos se cargan correctamente"
   ```

4. **Commit** (Claude Code)
   ```
   "git add . && git commit -m 'FASE 2: Catálogos calderines'"
   ```

5. **Push**
   ```
   git push origin nombre-rama
   ```

---

## 🎯 PARTE 3: VENTAJAS DE USAR GITHUB + CLAUDE CODE

### ✅ Ventajas del combo:

1. **Historial completo**
   - Cada cambio queda registrado
   - Puedes volver atrás si algo falla

2. **Trabajo incremental**
   - Hacer cambios pequeños y testarlos
   - No perder nunca el código funcional

3. **Colaboración** (si añades colaboradores)
   - Pull requests para revisión
   - Comentarios en el código

4. **Claude Code puede leer TODO tu proyecto**
   - Ve todos los archivos a la vez
   - Entiende dependencias entre módulos

5. **Automatización**
   - Claude Code puede ejecutar tus macros VBA
   - Puede generar documentación automática

---

## 🎯 PARTE 4: TIPS ESPECÍFICOS PARA VBA

### Estructura de carpetas recomendada:
```
ofergas/
├── VBA_modules/           # Archivos .bas
│   ├── modOfertaTypes.bas
│   ├── modMACROLeerOfertas.bas
│   └── modHelpers.bas
├── VBA_classes/           # Archivos .cls
│   ├── clsCatalogos.cls
│   ├── clsOfertaRepository.cls
│   └── clsOferta.cls
├── Database/              # Scripts SQL, backups
│   └── estructura_BD.sql
├── Docs/                  # Documentación
│   ├── README_FASE1.txt
│   ├── ANALISIS_BD.md
│   └── diagramas/
│       └── BD_Ofertas_Gas.mermaid
└── Tests/                 # Macros de prueba
    └── test_catalogos.bas
```

### Prompt efectivo para Claude Code:
```
"Analiza la estructura actual del proyecto VBA.
Los archivos .cls y .bas están en [ubicación].
Sugiere cómo organizarlos mejor y crea la estructura."
```

---

## 🎯 PARTE 5: COMANDOS GIT ÚTILES

### Ver estado:
```bash
git status                    # Qué archivos cambiaron
git diff clsCatalogos.cls    # Ver cambios específicos
```

### Crear rama:
```bash
git checkout -b feature/nombre-feature
```

### Commit selectivo:
```bash
git add clsCatalogos.cls      # Solo este archivo
git commit -m "Descripción"
```

### Ver historial:
```bash
git log --oneline            # Historial compacto
git log --graph              # Con gráfico de ramas
```

### Deshacer cambios:
```bash
git checkout -- archivo.cls   # Descartar cambios
git reset HEAD~1              # Deshacer último commit
```

---

## 📚 RECURSOS OFICIALES DE ANTHROPIC

### Documentación Claude Code:
- https://docs.claude.ai/docs/claude-code

### Videos tutoriales:
- YouTube: Busca "Claude Code tutorial"
- Canal oficial Anthropic: https://www.youtube.com/@AnthropicAI

### Ejemplos de uso:
- https://docs.claude.ai/docs/resources/use-cases

### API y features avanzadas:
- https://docs.claude.ai/docs/build-with-claude

---

## 🎯 PRÓXIMOS PASOS PARA TI

### HOY (con los archivos que te doy):
1. ✅ Descargar ZIP
2. ✅ Subir a GitHub siguiendo PARTE 1
3. ✅ Importar los 4 archivos en tu proyecto VBA Access
4. ✅ Probar que compila sin errores
5. ✅ Ejecutar LeerOfertaCompleta y verificar resultados

### MAÑANA (con Claude Code):
1. Abrir proyecto en Claude Code
2. Pedirle que analice qué falta de FASE 2
3. Implementar FASE 2 paso a paso
4. Hacer commits incrementales

### PRÓXIMA SEMANA:
1. Completar FASE 3
2. Añadir tests automatizados
3. Documentar funciones principales
4. Optimizar performance si es necesario

---

## 💡 EJEMPLO DE SESIÓN COMPLETA EN CLAUDE CODE

```
TÚ: "Hola Claude, estoy trabajando en el proyecto ofergas. 
     Quiero implementar la FASE 2 que incluye los grupos F, G, I.
     Lee el archivo README_FASE1.txt para entender el contexto."

CLAUDE: [Lee el README]
        "Entiendo. La FASE 2 requiere implementar 9 catálogos más:
         - Grupo F: DepositosEntrada, DepositosFinal, TiposMaterial
         - Grupo G: TiposTubos, TiposPresionNominal, ValvulasSeguridad
         - Grupo I: TuberiasAire, TuberiasAireDiametros, TuberiasAgua
         
         ¿Quieres que empiece con el Grupo F?"

TÚ: "Sí, empieza con el Grupo F. Modifica los 4 archivos necesarios."

CLAUDE: [Modifica archivos]
        "He modificado:
         1. modOfertaTypes.bas - Añadidos 3 UDTs nuevos
         2. clsCatalogos.cls - Añadidos 3 catálogos con patrón arrays
         3. clsOfertaRepository.cls - Actualizado CargarCalderines
         4. modMACROLeerOfertas.bas - Actualizada visualización
         
         ¿Quieres que haga commit de estos cambios?"

TÚ: "Sí, haz commit"

CLAUDE: [Ejecuta git add y commit]
        "✅ Commit realizado: 'FASE 2 Grupo F: Catálogos depósitos y materiales'
         ¿Continuo con el Grupo G?"
```

---

## ❓ PREGUNTAS FRECUENTES

**P: ¿Claude Code puede ejecutar mis macros VBA?**
R: No directamente, pero puede generar scripts que las ejecuten desde línea de comandos usando COM automation.

**P: ¿Puedo usar Claude Code con archivos .accdb?**
R: Sí, pero Claude trabaja mejor con archivos de texto (.cls, .bas). Para .accdb necesitas exportar/importar módulos.

**P: ¿Cómo paso código de claude.ai a Claude Code?**
R: Copia los archivos que claude.ai te da, súbelos a GitHub, y luego clona el repo en Claude Code.

**P: ¿Claude Code funciona offline?**
R: No, necesita conexión a internet para comunicarse con los servidores de Claude.

**P: ¿Cuánto cuesta Claude Code?**
R: Incluido en tu suscripción Pro. Sin costo adicional.

---

## 🎓 RETO FINAL: COMPLETA LA FASE 2 TÚ SOLO

Cuando termines la FASE 1 que te entrego hoy, intenta completar la FASE 2 usando Claude Code siguiendo estos pasos:

1. Abre Claude Code en tu proyecto
2. Dale este prompt:
   ```
   "Lee README_FASE1.txt y los 4 archivos VBA.
   Implementa la FASE 2 (grupos F, G, I) siguiendo
   exactamente el mismo patrón que usé en FASE 1.
   Hazlo paso a paso, grupo por grupo, explicándome
   qué estás haciendo."
   ```

3. Revisa cada cambio que proponga
4. Haz commit después de cada grupo
5. Prueba que compila y funciona

**¡Éxito! 🚀**

