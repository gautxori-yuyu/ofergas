================================================================================
CAMBIOS PENDIENTES EN clsOfertaRepository.cls y modMACROLeerOfertas.bas
================================================================================

Los archivos clsOfertaRepository.cls y modMACROLeerOfertas.bas incluidos en este
ZIP están SIN MODIFICAR (versión antigua).

NECESITAS AÑADIR MANUALMENTE las secciones de resolución de FKs.

================================================================================
OPCIÓN RECOMENDADA: USA CLAUDE CODE
================================================================================

En lugar de hacer estos cambios manualmente, usa Claude Code:

1. Sube TODOS los archivos de este ZIP a tu repo GitHub
2. Abre Claude Code en tu proyecto
3. Dale este prompt:

   "Lee estos 4 archivos VBA:
    - modOfertaTypes.bas (tiene 32 UDTs nuevos)
    - clsCatalogos.cls (tiene 32 catálogos nuevos con métodos ObtenerXXX)
    - clsOfertaRepository.cls
    - modMACROLeerOfertas.bas
    
    Necesito que modifiques clsOfertaRepository.cls y modMACROLeerOfertas.bas
    para resolver las FKs de los 32 catálogos nuevos.
    
    Para cada FK nueva (ej: PUMA_ID), debes:
    1. En CargarExtras: llamar m_Catalogos.ObtenerPuestasMarcha(PUMA_ID)
    2. Copiar los campos del UDT al tipo tOfertasExtras
    3. En LeerOfertaCompleta: mostrar PUMA_MODELO en lugar de PUMA_ID
    
    Hazlo grupo por grupo, empezando por Grupo A (Extras)."

4. Claude Code hará TODOS los cambios automáticamente
5. Revisa que compile sin errores
6. Haz commit

================================================================================
SI PREFIERES HACERLO MANUAL (no recomendado)
================================================================================

Aquí tienes las secciones exactas a modificar:

-------------------------------------------------------------------
ARCHIVO: clsOfertaRepository.cls
-------------------------------------------------------------------

CAMBIO 1: En CargarDatosGenerales (aprox línea 90)
DESPUÉS de esta línea:
    m_DatosGenerales.GASE_ID = NzLong(rs("GASE_ID"))

AÑADIR:
    ' Resolver FKs de datos generales
    If m_DatosGenerales.PAIS_ID > 0 Then
        Dim pais As tCatalogPaises
        pais = m_Catalogos.ObtenerPaises(m_DatosGenerales.PAIS_ID)
        m_DatosGenerales.PAIS_NOMBRE = pais.pais_nombre
    End If
    
    If m_DatosGenerales.COME_ID > 0 Then
        Dim come As tCatalogComerciales
        come = m_Catalogos.ObtenerComerciales(m_DatosGenerales.COME_ID)
        m_DatosGenerales.COME_NOMBRE = come.COME_NOMBRE
    End If
    
    If m_DatosGenerales.OFTN_ID > 0 Then
        Dim oftn As tCatalogOfertantes
        oftn = m_Catalogos.ObtenerOfertantes(m_DatosGenerales.OFTN_ID)
        m_DatosGenerales.OFTN_NOMBRE = oftn.OFTN_NOMBRE
    End If
    
    If m_DatosGenerales.GASE_ID > 0 Then
        Dim gase As tCatalogGases
        gase = m_Catalogos.ObtenerGases(m_DatosGenerales.GASE_ID)
        m_DatosGenerales.GASE_DENOMINACION = gase.GASE_DENOMINACION
    End If

-------------------------------------------------------------------

CAMBIO 2: En CargarExtras (aprox línea 300)
DESPUÉS de cargar todos los campos del recordset, ANTES del rs.Close

AÑADIR:
    ' Resolver FKs de extras (Grupo A)
    If m_Extras.EMBA_ID > 0 Then
        Dim emba As tCatalogEmbalajes
        emba = m_Catalogos.ObtenerEmbalajes(m_Extras.EMBA_ID)
        m_Extras.OFEX_EMBA_DESCRIPCION = emba.EMBA_MODELO & " - " & emba.EMBA_DESCRIPCION
        If m_Extras.OFEX_EMBA_PRE_COSTE = 0 Then
            m_Extras.OFEX_EMBA_PRE_COSTE = emba.EMBA_PRE_COSTE
        End If
    End If
    
    ' (Similar para TRAN_ID, PUMA_ID, PRA1_ID, PRA2_ID, PRA3_ID, PRA4_ID)
    ' ... VER PATRÓN COMPLETO EN GUIA_CLAUDE_CODE_GITHUB.md

-------------------------------------------------------------------

CAMBIO 3: En CargarAccesorios (aprox línea 250)
AÑADIR resolución de:
- AERO_ID, CALO_ID, GREN_ID, LLEN_ID, LLSA_ID
- ARRA_ID (con lógica especial según OFAC_ARRA_TIPO)

-------------------------------------------------------------------

CAMBIO 4: En CargarCabezal (aprox línea 180)
AÑADIR resolución de:
- NORC_ID

-------------------------------------------------------------------

CAMBIO 5: En CargarOpciones (aprox línea 220)
AÑADIR resolución de:
- VAPR_ID, ENCI_ID, PURG_ID, RESC_ID, VARG_ID

-------------------------------------------------------------------

CAMBIO 6: En CargarInstrumentacion (aprox línea 270)
AÑADIR resolución de:
- TRAT_ID, TRAP_ID, TERM_ID, ELER_ID, SECV_ID
- INTV_ID, INTA_ID, NIVC_ID, VATE_ID, INTR_ID

-------------------------------------------------------------------
ARCHIVO: modMACROLeerOfertas.bas
-------------------------------------------------------------------

CAMBIO: En LeerOfertaCompleta (línea ~50)

REEMPLAZAR líneas que muestran IDs:
    Debug.Print "Pais ID: " & ofe.DatosGenerales.PAIS_ID

POR líneas que muestran datos de catálogo:
    Debug.Print "País: " & ofe.DatosGenerales.PAIS_NOMBRE

AÑADIR prefijo ' a OFER_NUM_OFERTA:
    ws.Range("B2").Value = "'" & ofe.DatosGenerales.OFER_NUM_OFERTA

================================================================================
IMPORTANTE
================================================================================

Si optas por hacerlo manual, ten en cuenta:
- Son ~150 líneas de código a añadir
- Muy repetitivo (mismo patrón para cada FK)
- Alto riesgo de errores tipográficos
- Tardarás 2-3 horas

Con Claude Code tardarás 10 minutos y sin errores.

================================================================================
